# -*- coding: utf-8 -*-
"""
Created on Mon Mar  8 22:18:42 2021

@author: Administrator
"""

from collections import defaultdict
import numpy as np
import random, pdb
from tqdm import tqdm


def read_rating_txt(file_name):
    '''
    read user-item rating records
    retrun dict: {user:[items]}
    '''
    file = open(file_name)
    user_items = defaultdict(set) 
    item_users = defaultdict(set)
    for _,line in enumerate(file):
        tmp = line.strip().split('|')
        user, item = int(tmp[0]), int(tmp[1])
        item_users[item].add(user)
        user_items[user].add(item)     
    print('----------------------')
    print('rating set')
    print('user:', len(user_items))
    print('item:', len(item_users))    
    return user_items, item_users


def filter_item(k1, k2, item_users):
    '''
    filter item >=k1 <=k2
    '''
    user_ratings = defaultdict(set)
    userset = set()
    itemset = set()
    for item,users in item_users.items():
        if len(users) >= k1 and len(users) <= k2:
            for u in users:
                user_ratings[u].add(item)
                userset.add(u)
                itemset.add(item)
    print('len_u:', len(userset), 'max_uid:', max(userset))
    print('len_i:', len(itemset), 'max_iid:', max(itemset))
    return userset, itemset, user_ratings


def read_social_txt(file_name):
    '''
    read user-user social links
    return dict: {user:[users]}
    '''
    file = open(file_name)
    social_links = defaultdict(set)
    userset = set()
    for line in tqdm(file):
        u1,soc_list = line.split('|')
        soc_list = soc_list.strip().split(' ')
        userset.add(int(u1))
        for u2 in soc_list:
            social_links[int(u1)].add(int(u2))
            userset.add(int(u2))
    print('len_u:', len(userset), 'max_uid:', max(userset))
    return userset, social_links



def filter_users(k1, k2, k3, k4, user_ratings, social_links):
    '''
    filter users who ratings less than k1 or social links less than k2
    return dict:
    '''
    save_ratings = {}
    save_links = {}
    userset = set()
    ##################筛选符合条件的user##################
    for key in user_ratings.keys():
        len_ratings = len(user_ratings[key])
        len_links = len(social_links[key])
        if len_ratings >= k1 and len_ratings <= k2 and len_links >= k3 and len_links <= k4:
            save_ratings[key] = user_ratings[key]
            save_links[key] = social_links[key] 
            userset.add(key)

    ############## 删除social_links中不符合条件的用户#########
    users_no_links = set()
    new_links = {}
    for key in save_links.keys():
        u_list = []
        for uid in save_links[key]:
            if uid in userset:
                u_list.append(uid)
        if len(u_list) != 0:
            new_links[key] = u_list
        else:
            users_no_links.add(key) #这部分User是没有social信息的，所以只能是infor域的用户，并且不能是commen，在重命名user id的时候，我会把这些用户放在最前面
    print('original_users:{:d}, filtered_users:{:d}'.format(len(user_ratings),len(save_ratings)))
    print('filtered_social_users:{:d}'.format(len(new_links)))
    
    ### rename user id
    user_id = {}
    k = 0
    for uid in users_no_links:
        user_id[uid] = k
        k += 1
    for uid in (userset-users_no_links):
        user_id[uid] = k
        k += 1
    ### rename item id
#    pdb.set_trace()
    itemset = set()
    for key, items in save_ratings.items():
        for item in items:
            itemset.add(item)
    item_id = dict(zip(itemset, range(len(itemset))))    
    ### 重新写rating和social links
    final_ratings = {}
    final_links = {}

    for key, items in save_ratings.items():
        tmp_u = user_id[key]
        tmp_list = []
        for item in items:
            tmp_i = item_id[item]
            tmp_list.append(tmp_i)
        final_ratings[tmp_u] = tmp_list
    for key, items in new_links.items():
        tmp_u1 = user_id[key]
        tmp_list = []
        for item in items:
            tmp_u2 = user_id[item]
            tmp_list.append(tmp_u2)
        final_links[tmp_u1] = tmp_list  
    print('user_count:', len(user_id), 'item_count:', len(item_id))
    return final_ratings, final_links, users_no_links


def split_data(all_ratings, alpha=0.8):
    '''
    alpha: the percentage of traindata on alldata
    return: traindata and testdata
    '''
    traindata, testdata = {}, {}
    user_count, item_count = 16970, 8842
    for key in all_ratings.keys():
        if key >= user_count:
            print('user id error')
            pdb.set_trace()
        for iid in all_ratings[key]:
            if iid >= item_count:
                print('item id error')
                pdb.set_trace()  ### test user/item id rename is right
        traindata[key] = random.sample(all_ratings[key], int(len(all_ratings[key])*alpha))
        testdata[key] = list(set(all_ratings[key]).symmetric_difference(traindata[key]))
    return traindata, testdata


def split_infor_soc(infor_train_data, infor_test_data, final_ratings, final_links):
    user_count, item_count = 16970, 8842
    infor_domain = list(range(int(user_count*0.6))) #34598
    social_domain = []
    for u in range(int(user_count*0.5),user_count):
        social_domain.append(u)
    
    print('infor user:', max(infor_domain))
    print('social user len & min & max:', len(social_domain), min(social_domain), max(social_domain))


    infor_train = defaultdict(set)
    infor_test = defaultdict(set)
    social_link = defaultdict(set)
    social_rating = defaultdict(set)
    for user in infor_domain:
        infor_train[user] = infor_train_data[user]
        infor_test[user] = infor_test_data[user]


    common_user = set()
    for user in infor_domain:
        if user in social_domain:
            common_user.add(user)
    print('length common user: {}, min: {}, max:{}'.format(len(common_user), min(common_user), max(common_user)))


    social_user = set()
    for user in common_user:
        friends = final_links[user]
        for f in friends:
            if f in social_domain:
                social_link[user].add(f)
                social_link[f].add(user)
                social_user.add(f)
                
    social_user_1 = set()
    for user in social_user:
        friends = final_links[user]
        for f in friends:
            if f in social_domain:
                social_link[user].add(f)
                social_link[f].add(user)
                social_user_1.add(f)

    social_user_2 = set()
    for user in social_user_1:
        friends = final_links[user]
        for f in friends:
            if f in social_domain:
                social_link[user].add(f)
                social_link[f].add(user)
                social_user_2.add(f)

    social_user_3 = set()
    for user in social_user_2:
        friends = final_links[user]
        for f in friends:
            if f in social_domain:
                social_link[user].add(f)
                social_link[f].add(user)
                social_user_3.add(f)




    social_domain_user = set()
    for user, friends in social_link.items():
        social_domain_user.add(user)
        for f in friends:
            social_domain_user.add(f)
    

    social_user_reorder = dict()
    k = 0
    for user in social_domain_user:
        if user not in social_user_reorder:
            if user in common_user:
                social_user_reorder[user] = user
            else:
                social_user_reorder[user] = 10182 + k
                k += 1

    
    social_link_final = defaultdict(set)
    for user, friends in social_link.items():
        for friend in friends:
            u = social_user_reorder[user]
            f = social_user_reorder[friend]
            social_link_final[u].add(f)


    item_reorder = dict()
    k = 0
    for user,items in infor_train.items():
        for i in items:
            if i not in item_reorder:
                item_reorder[i] = len(item_reorder.keys())



    final_infor_train = defaultdict(set)
    final_infor_test = defaultdict(set)

    for user, items in infor_train.items():
        for i in items:
            final_infor_train[user].add(item_reorder[i])
    
    for user, items in infor_test.items():
        for i in items:
            if i in item_reorder:
                final_infor_test[user].add(item_reorder[i])



    for user in social_link:
        if user in infor_domain:
            for i in infor_test[user]:
                if i in item_reorder:
                    social_rating[social_user_reorder[user]].add(item_reorder[i])
            
        else:
            for i in final_ratings[user]:
                if i in item_reorder:
                    social_rating[social_user_reorder[user]].add(item_reorder[i])

    return final_infor_train, final_infor_test, social_link_final, social_rating



if __name__ == '__main__':
    data_path = '/content/drive/MyDrive/DASR-WGAN/src/dataprocess/'
    data_path_1 = '/content/drive/MyDrive/DASR-WGAN/data/dianping/version3/'
    infor_ratings, item_dict = read_rating_txt(data_path+'rating.txt')
    infor_users, infor_items, user_ratings = filter_item(5,400,item_dict)
    social_users, social_links = read_social_txt(data_path+'user.txt')
    final_ratings, final_links, users_no_links = filter_users(5, 400, 5, 400, user_ratings, social_links)
    
    infor_train_data, infor_test_data = split_data(final_ratings)

    infor_train, infor_test, social_link, social_rating = split_infor_soc(infor_train_data, infor_test_data, final_ratings, final_links)

    #'''
    np.save(data_path_1+'soc_ratings.npy', social_rating)
    np.save(data_path_1+'infor_train.npy', infor_train)
    np.save(data_path_1+'infor_test.npy', infor_test)
    np.save(data_path_1+'social_links.npy', social_link)
    print('done')
    #'''
    
    
    










    
        